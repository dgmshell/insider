<!--== #HEADER ==-->
<?php adminHeader($data); ?>
<!--== #NAV ==-->
<?php adminNav($data); ?>
<h1>Dashboard</h1>
<!--== #FOOTER ==-->
<?php adminFooter($data); ?>