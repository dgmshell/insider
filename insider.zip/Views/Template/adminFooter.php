<script src="<?php echo files() ?>js/libraries/toast.js"></script>
<script type="module" src="<?php echo files() ?>js/helpers/http.js"></script>
</body>
</html>