<div class="navbar">
    <div class="navbar-content">
        <div class="left">
            <a href="<?php echo router(); ?>dashboard">Dashboard</a>
            <a href="<?php echo router(); ?>payroll ">Planilla</a>
            <a href="<?php echo router(); ?>logout ">Salir</a>
        </div>
    </div>
</div>